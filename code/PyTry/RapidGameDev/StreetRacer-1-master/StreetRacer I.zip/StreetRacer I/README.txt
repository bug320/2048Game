INSTRUCTIONS
Double click the StreetRacer.py file in the game folder. The game starts immediately.

Avoid the other cars by moving the green car (player) left and right using the arrow keys.

IMPORTANT
All the files in the game folder are compulsory for the game to work, except the README.txt. Any deleting or redirecting of files or folders may cause the game to behave unexpectedly or to stop working completely.

ABOUT
StreetRacer I was build in Python using the pygame Library. 

CREDITS
Music by Jim Yosef @ https://www.youtube.com/channel/UCf5q0cbFOLbphljteZ9d4Pw

Python 3 @ https://www.python.org/

Pygame Library for Python 3 @ https://www.pygame.org

Font: Joystix Monospace by Raymond Larabie @ http://www.1001fonts.com/pixel+video-game-fonts.html 